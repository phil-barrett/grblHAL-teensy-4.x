grblHAL Hex files for T41U5XBB breakout board

This zip file contains grblHAL binaries (hex) for the T41U5XBB breakout board.  They can be directly loaded using the Teensy loader from pjrc.com.

File naming convention

grblHAL_T41<connection><axes><ganging><autosquaring><quad encoder>.hex
where:
	grblHAL_T41 - for Teensy 4.1
	<connection> - U for USB, E for Ethernet  (Ethernet also supports USB).
	<axes> - 3, 4 or 5 Axes.
	<ganging> - GX, GY or GZ for the axis ganged to.  If missing, no ganging.
	<autosquaring> - AS if autosquaring. If missing, no autosquaring.  AS requires sensors/switches for both ganged motors.
	<quad encoder> - QEI if present.
	.hex - indicates a hex file for loading via Teensy loader