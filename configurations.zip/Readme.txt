Find the configuration that you want to load ito your Teensy 4.1 and 
copy it to a directory/folder.  In the Teensy loader, open that file 
and then press the button on the Teensy 4.1. You should see a brief
loading message and your Teensy will then be ready to use.

Verify that you have loaded the correct version by sending grblHAL a "$i" command.  The response should have a line that calls out your options in the form: [DRIVER OPTIONS: ...]

The teensy loader is provided with Teensyduino (available here: https://www.pjrc.com/teensy/td_download.html) or can be downloaded directly from here: https://www.pjrc.com/teensy/loader.html. If you are not planning to make any changes to grblHAL, there is no need to download and install Teensyduino.